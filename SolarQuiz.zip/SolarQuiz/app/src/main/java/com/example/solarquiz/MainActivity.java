package com.example.solarquiz;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button answer1, answer2, answer3, answer4;

    TextView score, question;

    private final Questions mQuestions = new Questions();

    private String mAnswer;
    private int mScore=0;
    private final int mQuestionLength =mQuestions.mQuestions.length;

    Random r = new Random();

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        answer1= findViewById(R.id.answer1);
        answer2= findViewById(R.id.answer2);
        answer3= findViewById(R.id.answer3);
        answer4= findViewById(R.id.answer4);

        score= findViewById(R.id.score);
        question= findViewById(R.id.question);
        score.setText("Score "+mScore);
        updateQuestion(r.nextInt(mQuestionLength));
        answer1.setOnClickListener(v -> {
            if(answer1.getText()==mAnswer){
                mScore++;
                score.setText("Score "+mScore);
                updateQuestion(r.nextInt(mQuestionLength));
            }else {
                gameOver();
            }
        });
        answer2.setOnClickListener(v -> {
            if(answer2.getText()==mAnswer){
                mScore++;
                score.setText("Score "+mScore);
                updateQuestion(r.nextInt(mQuestionLength));
            }else {
                gameOver();
            }
        });
        answer3.setOnClickListener(v -> {
            if(answer3.getText()==mAnswer){
                mScore++;
                score.setText("Score "+mScore);
                updateQuestion(r.nextInt(mQuestionLength));
            }else {
                gameOver();
            }
        });
        answer4.setOnClickListener(v -> {
            if(answer4.getText()==mAnswer){
                mScore++;
                score.setText("Score "+mScore);
                updateQuestion(r.nextInt(mQuestionLength));
            }else {
                gameOver();
            }
        });
    }
    private void updateQuestion(int num){
        question.setText(mQuestions.getQuestion(num));
        answer1.setText(mQuestions.getChoice1(num));
        answer2.setText(mQuestions.getChoice2(num));
        answer3.setText(mQuestions.getChoice3(num));
        answer4.setText(mQuestions.getChoice4(num));

        mAnswer=mQuestions.getCorrectAnswer(num);
    }

    private void gameOver(){
        AlertDialog.Builder alertDialogBuilder=new AlertDialog.Builder(MainActivity.this);
        alertDialogBuilder
                .setMessage("Game Over! Your score is "+ mScore+ " points")
                .setCancelable(false)
                .setPositiveButton("New Game",
                        (dialogInterface, i) -> startActivity(new Intent(getApplicationContext(),MainActivity.class)))
                .setNegativeButton("Exit",
                        (dialog, i) -> finish());
    }
}



